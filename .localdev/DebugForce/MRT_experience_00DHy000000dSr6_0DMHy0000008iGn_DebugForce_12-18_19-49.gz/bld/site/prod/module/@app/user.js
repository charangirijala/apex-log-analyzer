LWR.define('@app/user', [], function() { return {
  "isGuest": true,
  "id": null,
  "csrfToken": null
}; });