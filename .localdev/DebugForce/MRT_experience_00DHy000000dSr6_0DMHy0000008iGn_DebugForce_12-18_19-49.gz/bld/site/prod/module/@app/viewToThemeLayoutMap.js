LWR.define('@app/viewToThemeLayoutMap', [], function() { return {
  "checkPasswordResetEmail": "scopedHeaderAndFooter",
  "newsDetail": "scopedHeaderAndFooter",
  "forgotPassword": "scopedHeaderAndFooter",
  "login": "scopedHeaderAndFooter",
  "error": "scopedHeaderAndFooter",
  "home": "scopedHeaderAndFooter",
  "register": "scopedHeaderAndFooter"
}; });